package com.example.customadapter_using_baseadapter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ListView list;
    String [] district={
        "Dhaka",
                "Ctg",
                "Khulna"
    };
   Integer[] imageId={
           R.drawable.dhaka,
           R.drawable.ctg,
           R.drawable.khulna
   };
   String[] date={ "22-Jan-16","31-Mar-19","19-July-2012"};
   String[] desc={ "Dhaka, also spelled Dacca, city and capital of Bangladesh. It is located just north of the Buriganga River, a channel of the Dhaleswari River, in the south-central part of the country. Dhaka is Bangladesh's most populous city and is one of the largest metropolises in South Asia",
           "Chittagong, officially called Chattogram, city that is the chief Indian Ocean port of Bangladesh. It lies about 12 miles (19 km) north of the mouth of the Karnaphuli River, in the southeastern arm of the country. Chittagong is the second largest city in Bangladesh, after Dhaka.",
           "Khulna is also a metropolitan city and this means it has a university, a medical college, a BIT, a Cantonment and a naval base. The city is also home to Bangladesh's largest ship building industry."};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list=findViewById(R.id.lv);
        CustomAdapter customAdapter=new CustomAdapter(MainActivity.this,district,imageId,date);
        list.setAdapter(customAdapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int imagesvv=imageId[position];
                String namevv=desc[position];

                Intent i=new Intent(getApplicationContext(),MainActivity2.class);

                i.putExtra("image",imagesvv);
                i.putExtra("namee",namevv);

                startActivity(i);

                //Toast.makeText(getApplicationContext(),"You Clicked on the news",Toast.LENGTH_SHORT).show();
            }
        });
    }

}
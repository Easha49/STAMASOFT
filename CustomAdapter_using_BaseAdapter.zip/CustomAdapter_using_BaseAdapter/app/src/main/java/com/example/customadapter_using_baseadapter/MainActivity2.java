package com.example.customadapter_using_baseadapter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
   ImageView img;
   TextView txt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        img=(ImageView)findViewById(R.id.img2);
        img.setImageResource(getIntent().getExtras().getInt("image"));

        txt= (TextView)findViewById(R.id.tv2);
        txt.setText(getIntent().getExtras().getString("namee"));
    }
}
package com.example.customadapter_using_baseadapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.annotation.NonNull;

public class CustomAdapter extends BaseAdapter {

    public CustomAdapter(Activity context, String[] district, Integer[] imageId, String[] date) {
        this.context = context;
        this.district = district;
        this.imageId = imageId;
        this.date = date;

    }

    private final Activity context;
    private final String [] district;
    private final Integer[] imageId;
    private final String[] date;


    @Override
    public int getCount(){
        return  district.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder vH = null;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.custom_layout, parent, false);
            vH = new ViewHolder(convertView);
            convertView.setTag(vH);
        }
       /* LayoutInflater inflater= context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.custom_layout,null,true);

        TextView txtTitle=(TextView) rowView.findViewById(R.id.txt1);
        ImageView imageView=(ImageView) rowView.findViewById(R.id.img);
        TextView txtDate=(TextView) rowView.findViewById(R.id.txt3);

        txtTitle.setText(district[position]);
        imageView.setImageResource(imageId[position]);
        txtDate.setText(date[position]);
        return rowView;*/
        else{ vH=(ViewHolder)convertView.getTag();}
        vH.txtTitle.setText(district[position]);
        vH.imageView.setImageResource(imageId[position]);
        vH.txtDate.setText(date[position]);
        return convertView;
    }

    private class ViewHolder{
        TextView txtTitle,txtDate;
        ImageView imageView;
        public ViewHolder(View view){
          txtTitle=(TextView)view.findViewById(R.id.txt1);
          txtDate=(TextView)view.findViewById(R.id.txt3);
          imageView=(ImageView) view.findViewById(R.id.img);

        }
    }

}
